# FDE-Case-Study
Docs Q&A assistant for Solstice Learning (FDE case study): grounded answers from product docs with source citations, and an honest "I don't have an answer" when the docs don't cover it, built with FastAPI, hybrid search and an LLM.

Project: [case-study-5-docs-qa-assistant/solstice-docs-qa](case-study-5-docs-qa-assistant/solstice-docs-qa)
